package com.example.helloworld1;

public class FoodInfo {
    public long id;
    public long image_id;
    public String name;
    public String phone;

    public FoodInfo(long id, long image_id, String name, String phone){
        this.id = id;
        this.image_id = image_id;
        this.name = name;
        this.phone = phone;
    }
}
