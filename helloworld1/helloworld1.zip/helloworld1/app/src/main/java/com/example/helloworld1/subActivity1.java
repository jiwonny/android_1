package com.example.helloworld1;

import android.app.Activity;
import android.os.Bundle;

//연락처
public class subActivity1 extends Activity {


    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub1);

    }


}
