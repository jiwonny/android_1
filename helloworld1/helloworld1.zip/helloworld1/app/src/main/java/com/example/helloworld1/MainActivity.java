package com.example.helloworld1;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import android.support.v4.app.FragmentManager;




import java.lang.annotation.Target;
public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findViewById(R.id.bt1).setOnClickListener(this);
        findViewById(R.id.bt2).setOnClickListener(this);
        findViewById(R.id.bt3).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.bt1:
                FragmentManager fm = getFragmentManager();
                android.app.FragmentTransaction ft = fm.beginTransaction();
                        ft.replace(R.id.main_frame, new Fragment1());
                        ft.commit();
                break;
            case R.id.bt2:
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.main_frame, new Fragment2())
                        .commit();
                break;
            case R.id.bt3:
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.main_frame, new Fragment3())
                        .commit();
                break;
        }
    }
}
